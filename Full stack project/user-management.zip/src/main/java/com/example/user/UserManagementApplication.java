package com.example.user;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.example.user.service.UserService;

@SpringBootApplication
public class UserManagementApplication {
    public static void main(String[] args) {
        SpringApplication.run(UserManagementApplication.class, args);
    }

    @Bean
    CommandLineRunner init(UserService userService) {
        return args -> {
            if (userService.countUsers() == 0) {
                userService.register("admin", "admin123", "Administrator", "admin@example.com", "9999999999", "ADMIN");
                userService.register("gunjan", "1234", "Gunjan Kamboj", "gunjan@example.com", "9876543210", "USER");
            }
        };
    }
}
