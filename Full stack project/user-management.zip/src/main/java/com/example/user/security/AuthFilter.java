package com.example.user.security;

import java.io.IOException;
import java.util.Optional;

import org.springframework.web.filter.OncePerRequestFilter;

import com.example.user.model.User;
import com.example.user.service.UserService;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class AuthFilter extends OncePerRequestFilter {
    private final UserService userService;
    public AuthFilter(UserService userService){ this.userService = userService; }
    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {
        String path = request.getRequestURI();
        if(path.startsWith("/api/auth") || path.startsWith("/h2-console") || path.startsWith("/actuator")) {
            filterChain.doFilter(request, response); return;
        }
        String token = request.getHeader("X-Auth-Token");
        if(token==null || token.isEmpty()){ response.setStatus(HttpServletResponse.SC_UNAUTHORIZED); response.getWriter().write("Missing X-Auth-Token"); return; }
        Optional<User> u = userService.findByToken(token);
        if(u.isEmpty()){ response.setStatus(HttpServletResponse.SC_UNAUTHORIZED); response.getWriter().write("Invalid token"); return; }
        filterChain.doFilter(request, response);
    }
}
