package com.example.user.controller;

import java.util.Map;
import java.util.Optional;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.user.model.User;
import com.example.user.service.UserService;

@RestController
@RequestMapping("/api/auth")
public class AuthController {
    private final UserService userService;
    public AuthController(UserService userService){ this.userService = userService; }

    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody Map<String,String> body){
        try{
            User u = userService.register(body.get("username"), body.get("password"), body.get("name"), body.get("email"), body.get("contact"), body.getOrDefault("role","USER"));
            return ResponseEntity.ok(Map.of("message","Registered","username", u.getUsername()));
        }catch(Exception e){
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody Map<String,String> body){
        try{
            String token = userService.login(body.get("username"), body.get("password"));
            return ResponseEntity.ok(Map.of("token", token));
        }catch(Exception e){
            return ResponseEntity.status(401).body(Map.of("error", e.getMessage()));
        }
    }

    @PostMapping("/logout")
    public ResponseEntity<?> logout(@RequestHeader(value="X-Auth-Token", required=false) String token){
        if(token!=null) userService.logout(token);
        return ResponseEntity.ok(Map.of("message","Logged out"));
    }

    @GetMapping("/me")
    public ResponseEntity<?> me(@RequestHeader("X-Auth-Token") String token){
        Optional<User> u = userService.findByToken(token);
        if(u.isEmpty()) return ResponseEntity.status(401).body(Map.of("error","Invalid token"));
        return ResponseEntity.ok(u.get());
    }

    @PutMapping("/me")
    public ResponseEntity<?> update(@RequestHeader("X-Auth-Token") String token, @RequestBody Map<String,String> body){
        Optional<User> u = userService.findByToken(token);
        if(u.isEmpty()) return ResponseEntity.status(401).body(Map.of("error","Invalid token"));
        userService.updateProfile(u.get().getUsername(), body.get("name"), body.get("email"), body.get("contact"));
        return ResponseEntity.ok(Map.of("message","Profile updated"));
    }

    @PutMapping("/change-password")
    public ResponseEntity<?> change(@RequestHeader("X-Auth-Token") String token, @RequestBody Map<String,String> body){
        Optional<User> u = userService.findByToken(token);
        if(u.isEmpty()) return ResponseEntity.status(401).body(Map.of("error","Invalid token"));
        try{
            userService.changePassword(u.get().getUsername(), body.get("oldPassword"), body.get("newPassword"));
            return ResponseEntity.ok(Map.of("message","Password changed"));
        }catch(Exception e){
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }
}
