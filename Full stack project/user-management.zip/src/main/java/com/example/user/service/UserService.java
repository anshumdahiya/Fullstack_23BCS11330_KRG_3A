package com.example.user.service;

import java.util.*;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.example.user.model.User;
import com.example.user.repository.UserRepository;

@Service
public class UserService {
    private final UserRepository userRepository;
    private final BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
    private final Map<String,String> tokenStore = new HashMap<>();

    public UserService(UserRepository userRepository){ this.userRepository = userRepository; }

    public long countUsers(){ return userRepository.count(); }

    public User register(String username, String rawPassword, String name, String email, String contact, String role){
        if(userRepository.existsByUsername(username)) throw new IllegalArgumentException("Username exists");
        User u = new User();
        u.setUsername(username);
        u.setPasswordHash(passwordEncoder.encode(rawPassword));
        u.setName(name); u.setEmail(email); u.setContact(contact);
        u.setRole(role==null? "USER": role.toUpperCase());
        return userRepository.save(u);
    }

    public String login(String username, String rawPassword){
        User u = userRepository.findByUsername(username).orElseThrow(() -> new IllegalArgumentException("Invalid credentials"));
        if(passwordEncoder.matches(rawPassword, u.getPasswordHash())){
            String token = UUID.randomUUID().toString();
            tokenStore.put(token, username);
            return token;
        }
        throw new IllegalArgumentException("Invalid credentials");
    }

    public void logout(String token){ tokenStore.remove(token); }

    public Optional<User> findByToken(String token){
        String username = tokenStore.get(token);
        if(username==null) return Optional.empty();
        return userRepository.findByUsername(username);
    }

    public void updateProfile(String username, String name, String email, String contact){
        User u = userRepository.findByUsername(username).orElseThrow();
        if(name!=null) u.setName(name);
        if(email!=null) u.setEmail(email);
        if(contact!=null) u.setContact(contact);
        userRepository.save(u);
    }

    public void changePassword(String username, String oldPass, String newPass){
        User u = userRepository.findByUsername(username).orElseThrow();
        if(!passwordEncoder.matches(oldPass, u.getPasswordHash())) throw new IllegalArgumentException("Old password incorrect");
        u.setPasswordHash(passwordEncoder.encode(newPass));
        userRepository.save(u);
    }

    public Map<String,String> getTokenStore(){ return Collections.unmodifiableMap(tokenStore); }
}
