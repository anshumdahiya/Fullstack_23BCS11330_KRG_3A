import React from 'react'

function Header() {
    return (
        <div>
            <h1>Header Section of WebPage</h1>
            <p>Application Starts form here</p>
        </div>
    )
}

export default Header
